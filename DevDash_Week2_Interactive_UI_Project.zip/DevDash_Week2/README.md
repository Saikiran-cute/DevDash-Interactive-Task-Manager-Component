# DevDash – Week 2 Interactive UI Component

This project extends the DevDash frontend concept with a reusable interactive task manager built using vanilla JavaScript.

## Features
- Add-task modal
- Client-side validation and error handling
- Complete/incomplete task toggling
- Delete tasks
- Search tasks
- All/Pending/Completed filters
- Live task statistics
- Responsive mobile layout
- ARIA attributes and keyboard-friendly controls
- Escape-key and backdrop modal closing
- HTML escaping for user-entered task titles

## Files
- `index.html`
- `css/style.css`
- `js/script.js`

## Run
Open `index.html` in a browser or use VS Code Live Server.

## Accessibility
Interactive controls use accessible names, `aria-expanded`/`aria-pressed` states where appropriate, `role="dialog"` for the modal, live updates through `aria-live`, and visible focus indicators.

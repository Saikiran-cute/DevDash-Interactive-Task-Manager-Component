const state = {
  tasks: [
    { id: 1, title: "Create responsive landing page", done: true },
    { id: 2, title: "Build interactive task component", done: false },
    { id: 3, title: "Review frontend accessibility", done: false }
  ],
  filter: "all",
  query: ""
};

const list = document.querySelector("#taskList");
const empty = document.querySelector("#emptyState");
const total = document.querySelector("#totalCount");
const completed = document.querySelector("#completedCount");
const pending = document.querySelector("#pendingCount");
const modal = document.querySelector("#modal");
const form = document.querySelector("#taskForm");
const titleInput = document.querySelector("#taskTitle");
const formError = document.querySelector("#formError");

function getVisibleTasks() {
  return state.tasks.filter(task => {
    const matchesFilter = state.filter === "all" ||
      (state.filter === "completed" && task.done) ||
      (state.filter === "pending" && !task.done);
    const matchesSearch = task.title.toLowerCase().includes(state.query.toLowerCase());
    return matchesFilter && matchesSearch;
  });
}

function render() {
  const tasks = getVisibleTasks();
  list.innerHTML = "";
  total.textContent = state.tasks.length;
  completed.textContent = state.tasks.filter(t => t.done).length;
  pending.textContent = state.tasks.filter(t => !t.done).length;

  empty.classList.toggle("hidden", tasks.length !== 0);

  tasks.forEach(task => {
    const item = document.createElement("article");
    item.className = `task ${task.done ? "done" : ""}`;
    item.innerHTML = `
      <button class="check" type="button" aria-label="${task.done ? "Mark incomplete" : "Mark complete"}" aria-pressed="${task.done}">${task.done ? "✓" : ""}</button>
      <div>
        <div class="title">${escapeHTML(task.title)}</div>
        <small>${task.done ? "Completed" : "Pending"}</small>
      </div>
      <button class="delete" type="button" aria-label="Delete ${escapeHTML(task.title)}">×</button>
    `;

    item.querySelector(".check").addEventListener("click", () => {
      task.done = !task.done;
      render();
    });

    item.querySelector(".delete").addEventListener("click", () => {
      state.tasks = state.tasks.filter(t => t.id !== task.id);
      render();
    });

    list.appendChild(item);
  });
}

function escapeHTML(value) {
  return value.replace(/[&<>"']/g, char => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[char]));
}

function openModal() {
  modal.classList.remove("hidden");
  formError.textContent = "";
  titleInput.value = "";
  titleInput.focus();
}

function closeModal() {
  modal.classList.add("hidden");
}

document.querySelector("#openModal").addEventListener("click", openModal);
document.querySelector("#closeModal").addEventListener("click", closeModal);
document.querySelector("#cancelModal").addEventListener("click", closeModal);

modal.addEventListener("click", e => {
  if (e.target === modal) closeModal();
});

document.addEventListener("keydown", e => {
  if (e.key === "Escape" && !modal.classList.contains("hidden")) closeModal();
});

form.addEventListener("submit", e => {
  e.preventDefault();
  const title = titleInput.value.trim();
  if (title.length < 3) {
    formError.textContent = "Please enter a task with at least 3 characters.";
    titleInput.focus();
    return;
  }
  state.tasks.unshift({ id: Date.now(), title, done: false });
  closeModal();
  render();
});

document.querySelectorAll(".filter").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".filter").forEach(btn => {
      btn.classList.remove("active");
      btn.setAttribute("aria-pressed", "false");
    });
    button.classList.add("active");
    button.setAttribute("aria-pressed", "true");
    state.filter = button.dataset.filter;
    render();
  });
});

document.querySelector("#searchInput").addEventListener("input", e => {
  state.query = e.target.value.trim();
  render();
});

render();
